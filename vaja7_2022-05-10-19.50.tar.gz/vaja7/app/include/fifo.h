#ifndef FIFO_H_INCLUDED
#define FIFO_H_INCLUDED

#include <stdint.h>


typedef struct {
uint32_t read_idx;
uint32_t write_idx;
uint32_t length;
uint8_t *buffer;
}fifo_t;

uint32_t fifo_read(fifo_t *fifo, uint8_t *data, uint32_t n);
uint32_t fifo_write(fifo_t *fifo, const uint8_t *data, uint32_t n);
void test_fifo(void);

#endif // FIFO_H_INCLUDED
