#ifndef RTOS_TASKS_H_INCLUDED
#define RTOS_TASKS_H_INCLUDED


void blink_driver(void);
void clock_task(void);
void text_task(void);
void btn_task(void);
void lcd_task(void);
void tekst_driver (void);
void tipke_driver (void);
void pulse_driver (void);

#endif // RTOS_TASKS_H_INCLUDED



