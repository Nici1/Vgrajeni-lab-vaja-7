#include <asf.h>
#include <rtos_tasks.h>
#include <rtos.h>
#include <ioport.h>
#include <test-more.h>
#include <lcd.h>
#include <fifo.h>



#define BTN_FIFO_SIZE 11
uint8_t btn_buff [BTN_FIFO_SIZE];
fifo_t btn_fifo=
{
    .read_idx =0,
    .write_idx=0,
    .length=BTN_FIFO_SIZE,
    .buffer=btn_buff
};
/*
    uint8_t tekst_buff [BTN_FIFO_SIZE];
    fifo_t tekst_fifo=
    {
        .read_idx =0,
        .write_idx=0,
        .length=BTN_FIFO_SIZE,
        .buffer=tekst_buff
    };
*/
/*
rtos_task_t task_blink = {
.last_tick=0,
.name="blink",
.fun=blink_driver
};
*/
/*
rtos_task_t task_gonilnik_ure = {
    .last_tick=0,
    .name="gonilnik ure",
    .fun=clock_task
};

rtos_task_t task_priprava_tekst = {
    .last_tick=1,
    .name="priprava tekst",
    .fun=text_task
};
*/
rtos_task_t task_gonilnik_lcd =
{
    .last_tick=2,
    .name="gonilnik lcd",
    .fun=lcd_task
};
/*
rtos_task_t task_gonilnik_tipke = {
    .last_tick=3,
    .name="gonilnik tipke",
    .fun=btn_task
};
*/

rtos_task_t task_tekst =
{
    .last_tick=0,
    .name="tekst",
    .fun=tekst_driver
};

void tekst_driver (void)
{

// prekopira vsebino fifo na lcd}
    /*
    for(int i=0;i<BTN_FIFO_SIZE;i++){
    tekst_buff[i]=btn_buff[i];
    sprintf(lcd_string,tekst_buff[i]);
    }
    */

    uint32_t i = 16;
    uint32_t j = btn_fifo.read_idx;

    for(int a=16; a<32; a++)
    {
        lcd_string[a]=' ';
    }

    while(i<32 && j!=btn_fifo.write_idx)
    {
        lcd_string[i]=btn_fifo.buffer[j];
        i++;
        j++;
        if(j == btn_fifo.length)
        {
            j = 0;
        }
    }


}

rtos_task_t task_btn =
{
    .last_tick=0,
    .name="tipke",
    .fun=tipke_driver
};

void tipke_driver (void)
{

// ob fronti tiple shrani ASCII v fifo
    uint8_t c;
    uint32_t btn = get_btn_press();
    uint32_t n;

    if ((btn & (1<<0) )!= 0)
    {
        c='1';
        n= fifo_write(&btn_fifo,&c,1);
    }


    if ((btn & (1<<1) )!= 0)
    {
        c='2';
        n= fifo_write(&btn_fifo,&c,1);
    }


    if((btn & (1<<2) )!= 0)
    {
        c='3';
        n= fifo_write(&btn_fifo,&c,1);
    }


    if ((btn & (1<<3) )!= 0)
    {
        c='4';
        n= fifo_write(&btn_fifo,&c,1);
    }


    if(n !=1)
    {
//fifo poln
    }

}

rtos_task_t task_pulse =
{
    .last_tick=0,
    .name="pulse",
    .fun=pulse_driver
};

void pulse_driver (void)
{

// skrbi za LED pulse, bere fifo za tipke

    static int counter=0;
    /*    static int32_t lt = 0;
        lt++;
        if (lt >= 10)
        {

            lt = 0;
        }

      */

    uint8_t c;
    static int max;
    uint8_t x;


    if(counter==0)
    {
        if(fifo_read(&btn_fifo,&c,1)!=0)
        {
            x=c-'0';
            max=x*5+50;
        }
        else
        {
            return;
        }
    }
    if(counter<max-50)
    {
        if(counter%5==0){
            ioport_set_pin_level(L1_IDX, 1);
        }
        if(counter%5==2){
            ioport_set_pin_level(L1_IDX, 0);
        }
    }
    counter++;
    if(counter==max){
        counter=0;
    }



    /*

        if(counter==0){ //nov znak

        }

        // obdelujem prejšnji znak


        counter++;
        //konec obdelave znaka
        if(counter==max){
            counter=0;
        }
    */
}


/*
void blink_driver(void){
ioport_toggle_pin_level(L1_IDX);
}
*/
/*
void clock_task(void){

time=time2/100;
//forata so ova e da se proveruva poveke pati
//vo sekunda t.e 100 so cel da bidat kopcinjata po responsive
sekunde=time % 60;
if(sekunde==0 && time>0){
minute++;
//sekunde=sekunde%60
}

minute=minute %60;
if(minute==0 && time>60){

ure++;
}


ure = ure % 24;

time2++;
}

void text_task(void){
uint16_t num=0;
int konec= sprintf(lcd_string,"%u",num);
lcd_string[konec]=' ';
}

void btn_task(void){
        int btn;
        int btn3;
        btn = get_btn_press();
        btn3=get_btn_state(); // state e potreben bidejki raboti na pozitivni vrednosti a ne na front
        if ((btn & (1<<0) )!= 0)
        {
            ure += 1;
        }


        if ((btn & (1<<1) )!= 0)
        {
            minute += 1;
        }


        if((btn3 & (1<<2) )!= 0)
        {
            time2--;
        }


        if ((btn & (1<<3) )!= 0)
        {
            time2=0;
            minute=0;
            ure=0;
        }
}
*/
void lcd_task(void)
{
    lcd_driver();
}

rtos_task_t *priv_task=0;

rtos_task_t *rtos_task_list[]= {&task_btn,&task_pulse,&task_tekst,&task_pulse,&task_gonilnik_lcd,&task_pulse,0};

