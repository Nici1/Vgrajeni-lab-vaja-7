#include <fifo.h>

uint32_t fifo_read(fifo_t *fifo, uint8_t *data, uint32_t n)
{
    /*
    Preberi fifo:
    fifo: naslov fifo strukturo
    data:
    n: št. byte-ov za branje
    */

    uint32_t i=0;

    for(i=0; i<n; i++)
    {
        if(fifo->write_idx != fifo->read_idx){ // fifo ni prazn

        if(fifo->read_idx==fifo->length-1)fifo->read_idx=0;

        data[i]= fifo->buffer[fifo->read_idx];
        fifo->read_idx++;
        }
        else
        {
            break;
        }

    }
    return i;


}
uint32_t fifo_write(fifo_t *fifo, const uint8_t *data, uint32_t n)
{

    /*
    Preberi fifo:
    fifo: naslov fifo strukturo
    data: naslov podatkov za vpis
    n: št. byte-ov za vpis
    */
    uint32_t i=0;

    for(i=0; i<n; i++)
    {
        uint32_t write = (fifo->write_idx+1) % fifo->length;
        if(write != fifo->read_idx)
        {
            fifo->buffer[fifo->write_idx] =data[i];
            fifo->write_idx=write;
        }
        else
        {
            break;
        }

    }
    return i;
}

#define TEST_FIFO_SIZE 7
uint8_t test_buff [TEST_FIFO_SIZE];
uint8_t read_data[10];
void test_fifo(void)
{
    fifo_t test_fifo=
    {
        .read_idx =0,
        .write_idx=0,
        .length=TEST_FIFO_SIZE,
        .buffer=test_buff
    };
    uint32_t num=fifo_write(&test_fifo,(const uint8_t *)"abcd",4);

    uint32_t num2 = fifo_read(&test_fifo,(uint8_t *)read_data,4);

}
