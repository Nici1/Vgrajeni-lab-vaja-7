#include <asf.h>
#include <rtos.h>

uint32_t rtos_init(uint32_t slice_us)
{

//config sys timer
//slice_us - cas rezine
//vrne 0 ok
//vrne 1 napaka

    SysTick->CTRL = 0<<2 | 1<<1;
    SysTick->LOAD = ((double)slice_us/1000000)*10500000;

    if(slice_us >= 1<<24)
    {

        return 1;
    }


    return 0;
}

void rtos_disable(void)
{
//vklopi/pozene rtos

SysTick->CTRL = 1<<1;
}

extern rtos_task_t *rtos_task_list[];
extern rtos_task_t *priv_task;

void rtos_enable(void)
{
//ustavi rtos

SysTick->CTRL |= 1<<0;
}

void SysTick_Handler()
{

    static uint32_t idx=0;
    static uint32_t tick=0;

    if(priv_task != 0){
    priv_task->fun();
    priv_task->last_tick=tick;
    }

    rtos_task_list[idx]->fun();
    rtos_task_list[idx]->last_tick=tick;
    idx++;
    if(rtos_task_list[idx]==0)
    {
        idx=0;
    }
    tick++;

//preveri scb
}
